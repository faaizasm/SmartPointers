#include "StringBuffer2.h"
#include "String2.h"
#include <memory>
#include <iostream>

using namespace std;
//default constructor

String2::String2() {
    this->_str = new StringBuffer2();
	this->own=true;
}
//destructor

String2::~String2() {

    //decrement the refcount and only if it is =0, delete the buffer.
    if (this->own) {
		delete[] this->_str;
    }

}

//copy a const String into this string

String2::String2(String2& newString) {
    if(newString.own)
	{
			this->_str = newString._str;	
			newString.own = false;
			this->own=true;
	}
	
    //increment the refcount by 1
}

//copy a char* into your string

String2::String2(char* newString, int length) {
    this->_str = new StringBuffer2(newString, length);
    //increment the refcount by 1
    this->own = true;

}

void String2::append(char c) 
{

    //    char* tempbuf = new char[this->_str->length()+1];
    //    this->_str->revSmartCopy(tempbuf);
    if (this->own) {
        //more than 1 reference to this string
       this->_str->append(c);
    } else {
        cout<<"Illegal effort, no ownership.\n";
    }

    //copy the new character at the end of this string


}

//get length of the string

int String2::length() const {
    return this->_str->length();
}

//get character at index if it is less than length

char String2::charAt(int index) const {
    if (index < this->_str->length()) {
        return this->_str->charAt(index);
    } else {
        //throw new IndexOutOfBoundException();

    }
}