/* 
 * File:   main.cpp
 *
 * Created on February 16, 2016, 9:51 PM
 */

#include <cstdlib>
#include <iostream>
#include<cstring>
#include "StringBuffer2.h"
#include "String2.h"
#include "StringBuffer4.h"
#include "String4.h"
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    //create a smart string
//    String ss;
    //create a smart string with const char*

	cout<<"--------------------TEST OWNED POINTERS-----------------------\n";
    char* hello = "hello";
    
    
    
    String2 ss2(hello,5);
	 cout<<"ss2 owner:"<<ss2.own<<endl;
	String2 ss3(hello,5);
	 cout<<"ss3 owner:"<<ss3.own<<endl;
    std::cout<<"ss2 length = "<<ss2.length()<<std::endl;
    cout<<hello<<endl;
    //multiple references
    String2 ss(ss2);
	 cout<<"ss owner:"<<ss.own<<endl;
    cout<<hello<<endl;
    //output statements
    std::cout<<"ss length = "<<ss.length()<<std::endl;
    std::cout<<"new ss charAt 0 = "<<ss.charAt(0)<<std::endl;
    cout<<ss.own<<endl;
	cout<<ss2.own<<endl;
	cout<<ss3.own<<endl;
    //append a character
    ss2.append('w');
    
    //out<<hello<<endl;
   // hello = "bye";
	
    std::cout<<"new ss2 charAt 0 = "<<ss2.charAt(0)<<std::endl;
	std::cout<<"new ss charAt 1 = "<<ss.charAt(1)<<std::endl;
	std::cout<<"new ss charAt 5 = "<<ss.charAt(5)<<std::endl;
	std::cout<<"new ss2 charAt 5 = "<<ss2.charAt(5)<<std::endl;
	std::cout<<"new ss3 charAt 5 = "<<ss3.charAt(5)<<std::endl;
    std::cout<<"new ss length = "<<ss.length()<<std::endl;
    std::cout<<"new ss2 length = "<<ss2.length()<<std::endl;


	ss.append('w');
    
    //out<<hello<<endl;
   // hello = "bye";
	
    std::cout<<"new ss2 charAt 0 = "<<ss2.charAt(0)<<std::endl;
	std::cout<<"new ss charAt 1 = "<<ss.charAt(1)<<std::endl;
	std::cout<<"new ss charAt 5 = "<<ss.charAt(5)<<std::endl;
	std::cout<<"new ss2 charAt 5 = "<<ss2.charAt(5)<<std::endl;
	std::cout<<"new ss3 charAt 5 = "<<ss3.charAt(5)<<std::endl;
    std::cout<<"new ss length = "<<ss.length()<<std::endl;
    std::cout<<"new ss2 length = "<<ss2.length()<<std::endl;
    cout<<"-------------------------------------------------------\n";
	cout<<"------------------TEST REFERENCE LINKING----------------------\n";


	 
    
    
    
    String4 s2(hello,5);
	 
	String4 s3(hello,5);
	 
    std::cout<<"s2 length = "<<ss2.length()<<std::endl;
    cout<<hello<<endl;
    //multiple references
    String4 s(s2);
	 
    cout<<hello<<endl;
    //output statements
    std::cout<<"new s length = "<<s.length()<<std::endl;
    std::cout<<"new s2 length = "<<s2.length()<<std::endl;
    std::cout<<"new s3 length = "<<s3.length()<<std::endl;


	std::cout<<"new s ref count = "<<s.getRefCount()<<std::endl;
	std::cout<<"new s2 ref count = "<<s2.getRefCount()<<std::endl;
	std::cout<<"new s3 ref count = "<<s3.getRefCount()<<std::endl;
    //append a character
	cout<<"***APPEND***"<<endl;
    s2.append('w');
    
    //out<<hello<<endl;
   // hello = "bye";
	
    std::cout<<"new s2 charAt 0 = "<<s2.charAt(0)<<std::endl;
	std::cout<<"new s charAt 1 = "<<s.charAt(1)<<std::endl;
	std::cout<<"new s charAt 1 = "<<s.charAt(1)<<std::endl;
	std::cout<<"new s charAt 5 = "<<s.charAt(5)<<std::endl;
	std::cout<<"new s2 charAt 5 = "<<s2.charAt(5)<<std::endl;
	std::cout<<"new s3 charAt 5 = "<<s3.charAt(5)<<std::endl;
    std::cout<<"new s length = "<<s.length()<<std::endl;
    std::cout<<"new s2 length = "<<s2.length()<<std::endl;
    std::cout<<"new s3 length = "<<s3.length()<<std::endl;
	std::cout<<"new s ref count = "<<s.getRefCount()<<std::endl;
	std::cout<<"new s2 ref count = "<<s2.getRefCount()<<std::endl;
	std::cout<<"new s3 ref count = "<<s3.getRefCount()<<std::endl;


	

	cout<<"-----------------------------------------------------------------\n";
	system("pause");
    return 0;
}

