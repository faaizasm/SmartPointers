/* 
 * File:   String4.h
 *
 * Created on December 6, 2016, 2:14 AM
 */

#ifndef STRING4_H
#define	STRING4_H

class String4{

public:
    String4();
    ~String4();
    String4(String4&);
    String4(char* ,int);
    void append(char);
    int length() const;
    char charAt(int) const;
	int getRefCount();
	StringBuffer4* _str;
	String4* next;
	String4* prev;
};


#endif	/* STRING_H */

