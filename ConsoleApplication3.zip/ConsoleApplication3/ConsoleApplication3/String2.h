/* 
 * File:   String2.h
 *
 * Created on Decemeber 5, 2016, 11:54 PM
 */

#ifndef STRING2_H
#define	STRING2_H

class String2{

public:
    String2();
    ~String2();
    String2(String2&);
    String2(char* ,int);
    void append(char);
    int length() const;
    char charAt(int) const;
	StringBuffer2* _str;
	bool own;
};


#endif	/* STRING_H */

