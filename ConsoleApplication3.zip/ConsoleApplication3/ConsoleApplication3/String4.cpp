#include "StringBuffer4.h"
#include "String4.h"
#include <memory>
#include <iostream>

using namespace std;
//default constructor

String4::String4() {

    this->_str = new StringBuffer4();
	this->next=NULL;
	this->prev=NULL;
}
//destructor

String4::~String4() {

    //decrement the refcount and only if it is =0, delete the buffer.

	
    if (this->next==this->prev) {
		this->next=NULL;
		this->prev=NULL;
		delete[] this->_str;
    }

}

//copy a const String into this string
String4::String4(String4& newString) {
    this->_str = newString._str;			
	this->next=NULL;
	this->prev=NULL;
    String4* temp=&newString;
	if(temp->next!=NULL)
	{
		while(temp->next!=this)
		{
			temp=temp->next;

		}
		temp->next = this;
		temp->next->next=&newString;
		temp->next->prev=temp;
		newString.prev=temp->next;
	}
	else
	{
		temp->next=this;
		temp->prev=temp->next;
		temp->next->next=temp;
		temp->next->prev=temp;

	}

	

}

//copy a char* into your string

String4::String4(char* newString, int length) {
    this->_str = new StringBuffer4(newString, length);

	//increment the refcount by 1
    this->next=NULL;
	this->prev=NULL;

}

void String4::append(char c) 
{

    //    char* tempbuf = new char[this->_str->length()+1];
    //    this->_str->revSmartCopy(tempbuf);
    if (this->next!=NULL) {
        //more than 1 reference to this string
        auto_ptr<StringBuffer4> newdata(new StringBuffer4);
        newdata.get()->reserve(this->_str->length() + 1);
        newdata.get()->smartCopy(this->_str);

        //decrement the reference count to this String
        this->next->prev=this->prev;
		this->prev->next=this->next;
		this->next=NULL;
		this->next=NULL;

        //cout<<"length at newdata"<<newdata.get()->length()<<endl;
        //now split the object instances
        this->_str = newdata.release();
    } else {
        this->_str->reserve(this->_str->length() + 1);
    }

    //copy the new character at the end of this string
    this->_str->append(c);

}

//get length of the string

int String4::length() const {
    return this->_str->length();
}

//get character at index if it is less than length

char String4::charAt(int index) const {
    if (index < this->_str->length()) {
        return this->_str->charAt(index);
    } else {
        //throw new IndexOutOfBoundException();

    }

}
int String4::getRefCount()
{
	int count=0;
	String4* temp=this;
	while((temp->next!=this) && (temp->next!=NULL))
	{
			temp=temp->next;
			count++;
	}

	return count+1;
}