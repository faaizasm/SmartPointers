#ifndef STRINGBUFFER4_H
#define	STRINGBUFFER4_H

class StringBuffer4{
public :
    StringBuffer4();
    ~StringBuffer4();
    StringBuffer4(const StringBuffer4&);
    StringBuffer4(char*,int);

    char charAt(int) const;
    int length() const;
    void smartCopy(char*,int);
    void smartCopy(StringBuffer4*);
    void revSmartCopy(char* newString);
    void reserve(int);
    void append(char);
private:
    char* _strbuf;
    int _length;
    
};

#endif	/* STRINGBUFFER4_H */

