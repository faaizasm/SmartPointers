#ifndef STRINGBUFFER2_H
#define	STRINGBUFFER2_H

class StringBuffer2{
public :
    StringBuffer2();
    ~StringBuffer2();
    StringBuffer2(const StringBuffer2&);
    StringBuffer2(char*,int);

    char charAt(int) const;
    int length() const;
    void smartCopy(char*,int);
    void smartCopy(StringBuffer2*);
    void revSmartCopy(char* newString);
    void reserve(int);
    void append(char);
    private:
    char* _strbuf;
    int _length;
    
};

#endif	/* STRINGBUFFER_H */

